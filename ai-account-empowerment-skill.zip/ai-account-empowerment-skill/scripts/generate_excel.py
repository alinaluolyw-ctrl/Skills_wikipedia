#!/usr/bin/env python3
"""
AI赋能Account团队 — Excel交付物生成脚本
生成以下工作表：
1. AI能力成熟度评估表
2. 培训计划与进度追踪表
3. ROI计算与效果追踪仪表板
4. KPI指标监控表
5. 场景优先级评分矩阵
"""

import openpyxl
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side, numbers
from openpyxl.utils import get_column_letter
from openpyxl.chart import BarChart, Reference, RadarChart
from copy import copy
import os

# ============================================================
# 样式定义
# ============================================================
# 颜色主题
COLOR_PRIMARY = "2E4057"      # 深蓝
COLOR_SECONDARY = "048A81"    # 青绿
COLOR_ACCENT1 = "F7B731"      # 金黄
COLOR_ACCENT2 = "FC5C65"      # 红橙
COLOR_LIGHT_BG = "F0F4F8"     # 浅灰蓝
COLOR_HEADER_BG = "2E4057"    # 深蓝背景
COLOR_SUB_HEADER = "048A81"   # 青绿子标题
COLOR_ROW_ALT = "EEF2F7"      # 交替行色
COLOR_GREEN = "27AE60"        # 绿色
COLOR_ORANGE = "F39C12"       # 橙色
COLOR_RED = "E74C3C"          # 红色

# 字体
font_title = Font(name='微软雅黑', size=16, bold=True, color="FFFFFF")
font_header = Font(name='微软雅黑', size=11, bold=True, color="FFFFFF")
font_sub_header = Font(name='微软雅黑', size=10, bold=True, color="FFFFFF")
font_body = Font(name='微软雅黑', size=10, color="333333")
font_body_bold = Font(name='微软雅黑', size=10, bold=True, color="333333")
font_small = Font(name='微软雅黑', size=9, color="666666")
font_score = Font(name='微软雅黑', size=12, bold=True, color="2E4057")

# 填充
fill_header = PatternFill(start_color=COLOR_PRIMARY, end_color=COLOR_PRIMARY, fill_type="solid")
fill_sub_header = PatternFill(start_color=COLOR_SECONDARY, end_color=COLOR_SECONDARY, fill_type="solid")
fill_light = PatternFill(start_color=COLOR_LIGHT_BG, end_color=COLOR_LIGHT_BG, fill_type="solid")
fill_alt_row = PatternFill(start_color=COLOR_ROW_ALT, end_color=COLOR_ROW_ALT, fill_type="solid")
fill_green = PatternFill(start_color="D5F5E3", end_color="D5F5E3", fill_type="solid")
fill_orange = PatternFill(start_color="FEF9E7", end_color="FEF9E7", fill_type="solid")
fill_red = PatternFill(start_color="FADBD8", end_color="FADBD8", fill_type="solid")
fill_accent1 = PatternFill(start_color=COLOR_ACCENT1, end_color=COLOR_ACCENT1, fill_type="solid")

# 对齐
align_center = Alignment(horizontal='center', vertical='center', wrap_text=True)
align_left = Alignment(horizontal='left', vertical='center', wrap_text=True)
align_right = Alignment(horizontal='right', vertical='center')

# 边框
thin_border = Border(
    left=Side(style='thin', color='CCCCCC'),
    right=Side(style='thin', color='CCCCCC'),
    top=Side(style='thin', color='CCCCCC'),
    bottom=Side(style='thin', color='CCCCCC')
)


def set_col_widths(ws, widths):
    """设置列宽"""
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w


def style_header_row(ws, row, start_col, end_col):
    """样式化表头行"""
    for col in range(start_col, end_col + 1):
        cell = ws.cell(row=row, column=col)
        cell.font = font_header
        cell.fill = fill_header
        cell.alignment = align_center
        cell.border = thin_border


def style_data_row(ws, row, start_col, end_col, is_alt=False):
    """样式化数据行"""
    for col in range(start_col, end_col + 1):
        cell = ws.cell(row=row, column=col)
        cell.font = font_body
        cell.alignment = align_center
        cell.border = thin_border
        if is_alt:
            cell.fill = fill_alt_row


# ============================================================
# Sheet 1: AI能力成熟度评估表
# ============================================================
def create_maturity_assessment(wb):
    ws = wb.create_sheet("1-AI能力成熟度评估")
    
    # 标题
    ws.merge_cells('A1:H1')
    ws['A1'] = "AI能力成熟度评估表 — Account团队"
    ws['A1'].font = font_title
    ws['A1'].fill = fill_header
    ws['A1'].alignment = align_center
    ws.row_dimensions[1].height = 40

    # 副标题
    ws.merge_cells('A2:H2')
    ws['A2'] = "评估周期：2026年Q1 | 评估人：______ | 评估日期：______"
    ws['A2'].font = font_small
    ws['A2'].alignment = align_center
    ws.row_dimensions[2].height = 25

    # 评估维度
    headers = ["评估维度", "评估指标", "权重", "自评分(1-10)", "他评分(1-10)", "综合得分", "等级", "改进建议"]
    dimensions = [
        ("一、工具使用能力", [
            ("AI工具日均使用时长", "15%"),
            ("使用场景多样化程度", "10%"),
            ("Prompt编写质量", "10%"),
        ]),
        ("二、业务应用深度", [
            ("客户分析报告AI辅助率", "12%"),
            ("文案创作AI辅助率", "10%"),
            ("数据复盘AI辅助率", "8%"),
        ]),
        ("三、学习与成长", [
            ("培训参与积极性", "8%"),
            ("自主探索新场景能力", "7%"),
            ("知识分享贡献", "5%"),
        ]),
        ("四、团队协作", [
            ("AI工作流标准化执行", "3%"),
            ("帮助同事AI使用", "2%"),
        ]),
    ]

    row = 4
    # 表头
    for col, h in enumerate(headers, 1):
        ws.cell(row=row, column=col, value=h)
    style_header_row(ws, row, 1, 8)
    ws.row_dimensions[row].height = 30
    row += 1

    for dim_name, items in dimensions:
        # 维度标题行
        ws.merge_cells(f'A{row}:B{row}')
        ws.cell(row=row, column=1, value=dim_name)
        ws.cell(row=row, column=1).font = font_body_bold
        ws.cell(row=row, column=1).fill = fill_sub_header
        ws.cell(row=row, column=1).font = Font(name='微软雅黑', size=10, bold=True, color="FFFFFF")
        ws.cell(row=row, column=1).alignment = align_left
        for col in range(1, 9):
            ws.cell(row=row, column=col).fill = fill_sub_header
            ws.cell(row=row, column=col).border = thin_border
        ws.row_dimensions[row].height = 28
        row += 1

        for idx, (item, weight) in enumerate(items):
            is_alt = idx % 2 == 1
            ws.cell(row=row, column=1, value="")  # 维度列合并后空
            ws.cell(row=row, column=2, value=item)
            ws.cell(row=row, column=3, value=weight)
            ws.cell(row=row, column=4, value="")  # 自评
            ws.cell(row=row, column=5, value="")  # 他评
            # 综合得分公式: (自评*0.4 + 他评*0.6)
            ws.cell(row=row, column=6).value = f'=IF(AND(D{row}<>"",E{row}<>""),D{row}*0.4+E{row}*0.6,"")'
            # 等级公式
            ws.cell(row=row, column=7).value = f'=IF(F{row}="","",IF(F{row}>=8,"优秀",IF(F{row}>=6,"良好",IF(F{row}>=4,"及格","需提升"))))'
            ws.cell(row=row, column=8, value="")  # 改进建议
            
            style_data_row(ws, row, 1, 8, is_alt)
            ws.cell(row=row, column=2).alignment = align_left
            ws.cell(row=row, column=8).alignment = align_left
            ws.row_dimensions[row].height = 28
            row += 1

    # 汇总行
    row += 1
    ws.merge_cells(f'A{row}:B{row}')
    ws.cell(row=row, column=1, value="综合评分")
    ws.cell(row=row, column=1).font = font_body_bold
    ws.cell(row=row, column=1).fill = fill_accent1
    ws.cell(row=row, column=1).alignment = align_center
    ws.cell(row=row, column=6).value = f'=SUMPRODUCT(F5:F{row-2},SUBSTITUTE(C5:C{row-2},"%","")/100)'
    ws.cell(row=row, column=6).font = font_score
    ws.cell(row=row, column=6).alignment = align_center
    for col in range(1, 9):
        ws.cell(row=row, column=col).border = thin_border
        ws.cell(row=row, column=col).fill = fill_accent1

    # 成熟度等级说明
    row += 2
    ws.cell(row=row, column=1, value="成熟度等级对照表：")
    ws.cell(row=row, column=1).font = font_body_bold
    row += 1
    levels = [("Level 1 探索期", "0-20分", "偶尔使用AI工具，无系统化应用"),
              ("Level 2 试点期", "21-40分", "部分团队使用AI，缺乏标准化流程"),
              ("Level 3 推广期", "41-60分", "多场景AI应用，工作流初步整合"),
              ("Level 4 融合期", "61-80分", "AI深度融入日常工作流，团队AI素养高"),
              ("Level 5 领先期", "81-100分", "AI成为核心竞争力，持续创新应用")]
    for level, score, desc in levels:
        ws.cell(row=row, column=1, value=level).font = font_body_bold
        ws.cell(row=row, column=2, value=score).font = font_body
        ws.cell(row=row, column=3, value=desc).font = font_small
        ws.merge_cells(f'C{row}:H{row}')
        row += 1

    set_col_widths(ws, [14, 22, 8, 12, 12, 10, 8, 22])
    return ws


# ============================================================
# Sheet 2: 培训计划与进度追踪表
# ============================================================
def create_training_plan(wb):
    ws = wb.create_sheet("2-培训计划与进度追踪")
    
    # 标题
    ws.merge_cells('A1:I1')
    ws['A1'] = "AI赋能培训计划与进度追踪 — 2026年度"
    ws['A1'].font = font_title
    ws['A1'].fill = fill_header
    ws['A1'].alignment = align_center
    ws.row_dimensions[1].height = 40

    # 表头
    headers = ["培训层级", "课程编号", "课程名称", "目标受众", "培训时长", "计划开展日期", "实际开展日期", "完成率", "满意度评分"]
    row = 3
    for col, h in enumerate(headers, 1):
        ws.cell(row=row, column=col, value=h)
    style_header_row(ws, row, 1, 9)
    ws.row_dimensions[row].height = 30

    # 培训数据
    training_data = [
        ("Layer 1\nAI基础素养", "1.1", "AI是什么？从概念到实用", "全团队必修", "2h", "2026-02-15", "", "", ""),
        ("", "1.2", "Prompt工程入门", "全团队必修", "3h", "2026-02-22", "", "", ""),
        ("", "1.3", "AI工作效率提升101", "全团队必修", "2h", "2026-03-01", "", "", ""),
        ("Layer 2\n业务场景应用", "2.1", "AI赋能客户沟通与方案策划", "Account团队", "4h", "2026-03-15", "", "", ""),
        ("", "2.2", "AI赋能执行监控与数据复盘", "Account团队", "4h", "2026-04-01", "", "", ""),
        ("", "2.3", "AI赋能社交媒体内容创作", "Account团队", "4h", "2026-04-15", "", "", ""),
        ("Layer 3\nAI领导力", "3.1", "AI团队管理与赋能策略", "管理层", "3h", "2026-05-01", "", "", ""),
        ("", "3.2", "AI驱动的客户价值创造", "管理层", "3h", "2026-05-15", "", "", ""),
        ("Layer 4\nAI布道师", "4.1", "AI工具深度研究与实验", "优秀学员", "持续", "2026-03-01", "", "", ""),
        ("", "4.2", "团队培训与知识分享技巧", "优秀学员", "2h", "2026-04-01", "", "", ""),
    ]

    row = 4
    for idx, data in enumerate(training_data):
        is_alt = idx % 2 == 1
        for col, val in enumerate(data, 1):
            ws.cell(row=row, column=col, value=val)
        style_data_row(ws, row, 1, 9, is_alt)
        ws.cell(row=row, column=1).alignment = align_center
        ws.cell(row=row, column=3).alignment = align_left
        ws.cell(row=row, column=4).alignment = align_left
        ws.row_dimensions[row].height = 32
        row += 1

    # 汇总行
    row += 1
    ws.cell(row=row, column=1, value="总计")
    ws.cell(row=row, column=1).font = font_body_bold
    ws.cell(row=row, column=5, value="25h")
    ws.cell(row=row, column=5).font = font_body_bold
    ws.cell(row=row, column=8).value = f'=AVERAGE(H4:H{row-2})'
    ws.cell(row=row, column=9).value = f'=AVERAGE(I4:I{row-2})'
    for col in range(1, 10):
        ws.cell(row=row, column=col).fill = fill_light
        ws.cell(row=row, column=col).border = thin_border
        ws.cell(row=row, column=col).font = font_body_bold

    # 进度追踪图例说明
    row += 2
    ws.cell(row=row, column=1, value="进度状态图例：")
    ws.cell(row=row, column=1).font = font_body_bold
    row += 1
    ws.cell(row=row, column=1, value="🟢 已完成(>80%)")
    ws.cell(row=row, column=3, value="🟡 进行中(40-80%)")
    ws.cell(row=row, column=5, value="🔴 未开启(<40%)")

    set_col_widths(ws, [12, 10, 24, 14, 10, 14, 14, 10, 10])
    return ws


# ============================================================
# Sheet 3: ROI计算与效果追踪仪表板
# ============================================================
def create_roi_dashboard(wb):
    ws = wb.create_sheet("3-ROI计算与效果追踪")
    
    # 标题
    ws.merge_cells('A1:H1')
    ws['A1'] = "AI赋能ROI计算与效果追踪仪表板"
    ws['A1'].font = font_title
    ws['A1'].fill = fill_header
    ws['A1'].alignment = align_center
    ws.row_dimensions[1].height = 40

    # === 输入参数区域 ===
    row = 3
    ws.merge_cells(f'A{row}:D{row}')
    ws.cell(row=row, column=1, value="📋 基础参数输入")
    ws.cell(row=row, column=1).font = font_sub_header
    ws.cell(row=row, column=1).fill = fill_sub_header
    ws.cell(row=row, column=1).alignment = align_center
    for col in range(1, 5):
        ws.cell(row=row, column=col).fill = fill_sub_header
        ws.cell(row=row, column=col).border = thin_border
    row += 1

    params = [
        ("团队规模（人）", "B4", 15),
        ("人均月产值（万元）", "B5", 8),
        ("每小时人力成本（元）", "B6", 80),
        ("月度AI工具费用（元）", "B7", 3000),
        ("月度培训投入（元）", "B8", 5000),
        ("人均每日节省工时（h）", "B9", 1.5),
        ("工作日数/月", "B10", 22),
    ]

    for idx, (label, cell, value) in enumerate(params):
        r = row + idx
        ws.cell(row=r, column=1, value=label)
        ws.cell(row=r, column=1).font = font_body_bold
        ws.cell(row=r, column=1).alignment = align_left
        ws[cell] = value
        ws[cell].font = font_score
        ws[cell].alignment = align_center
        ws[cell].fill = fill_green
        for col in range(1, 5):
            ws.cell(row=r, column=col).border = thin_border
            if col > 2:
                ws.cell(row=r, column=col).fill = fill_light

    row = 11
    # === ROI计算结果 ===
    ws.merge_cells(f'A{row}:D{row}')
    ws.cell(row=row, column=1, value="📊 ROI计算结果")
    ws.cell(row=row, column=1).font = font_sub_header
    ws.cell(row=row, column=1).fill = fill_sub_header
    ws.cell(row=row, column=1).alignment = align_center
    for col in range(1, 5):
        ws.cell(row=row, column=col).fill = fill_sub_header
        ws.cell(row=row, column=col).border = thin_border
    row += 1

    roi_items = [
        ("月度节省人工成本（元）", f'=B9*B10*B4*B6'),
        ("月度AI总投入（元）", f'=B7+B8'),
        ("月度净收益（元）", f'=B12-B13'),
        ("月度ROI（%）", f'=IF(B13>0,(B14/B13)*100,0)'),
        ("年度预计节省（元）", f'=B14*12'),
        ("投资回收周期（月）", f'=IF(B14>0,(B7+B8*3)/B14,"N/A")'),
    ]

    for idx, (label, formula) in enumerate(roi_items):
        r = row + idx
        ws.cell(row=r, column=1, value=label)
        ws.cell(row=r, column=1).font = font_body_bold
        ws.cell(row=r, column=1).alignment = align_left
        ws.cell(row=r, column=2).value = formula
        ws.cell(row=r, column=2).font = font_score
        ws.cell(row=r, column=2).alignment = align_center
        ws.cell(row=r, column=2).number_format = '#,##0'
        for col in range(1, 5):
            ws.cell(row=r, column=col).border = thin_border
            if col > 2:
                ws.cell(row=r, column=col).fill = fill_light

    # === 月度追踪表 ===
    row = 20
    ws.merge_cells(f'A{row}:H{row}')
    ws.cell(row=row, column=1, value="📈 月度效果追踪")
    ws.cell(row=row, column=1).font = font_sub_header
    ws.cell(row=row, column=1).fill = fill_sub_header
    ws.cell(row=row, column=1).alignment = align_center
    for col in range(1, 9):
        ws.cell(row=row, column=col).fill = fill_sub_header
        ws.cell(row=row, column=col).border = thin_border
    row += 1

    monthly_headers = ["指标", "1月", "2月", "3月", "4月", "5月", "6月", "目标值"]
    for col, h in enumerate(monthly_headers, 1):
        ws.cell(row=row, column=col, value=h)
    style_header_row(ws, row, 1, 8)
    row += 1

    monthly_metrics = [
        ("AI工具日均使用时长(min)", "", "", "", "", "", "", "30"),
        ("AI使用场景覆盖数", "", "", "", "", "", "", "5"),
        ("培训完成率(%)", "", "", "", "", "", "", "90"),
        ("人均产能提升率(%)", "", "", "", "", "", "", "30"),
        ("客户报告生成周期缩短率(%)", "", "", "", "", "", "", "40"),
        ("团队加班时长减少率(%)", "", "", "", "", "", "", "20"),
        ("客户满意度变化(分)", "", "", "", "", "", "", "+5"),
    ]

    for idx, data in enumerate(monthly_metrics):
        is_alt = idx % 2 == 1
        for col, val in enumerate(data, 1):
            ws.cell(row=row, column=col, value=val)
        style_data_row(ws, row, 1, 8, is_alt)
        ws.cell(row=row, column=1).alignment = align_left
        ws.row_dimensions[row].height = 26
        row += 1

    set_col_widths(ws, [22, 10, 10, 10, 10, 10, 10, 10])
    return ws


# ============================================================
# Sheet 4: KPI指标监控表
# ============================================================
def create_kpi_monitor(wb):
    ws = wb.create_sheet("4-KPI指标监控")
    
    # 标题
    ws.merge_cells('A1:G1')
    ws['A1'] = "AI赋能KPI指标监控表"
    ws['A1'].font = font_title
    ws['A1'].fill = fill_header
    ws['A1'].alignment = align_center
    ws.row_dimensions[1].height = 40

    # 表头
    headers = ["指标类别", "KPI指标", "单位", "基准值", "目标值", "当前值", "达成率(%)"]
    row = 3
    for col, h in enumerate(headers, 1):
        ws.cell(row=row, column=col, value=h)
    style_header_row(ws, row, 1, 7)
    ws.row_dimensions[row].height = 30

    kpi_data = [
        ("效率指标\n(Leading)", "AI工具日均使用时长", "min/人/天", "5", "30", "", ""),
        ("", "AI使用场景覆盖率", "个场景", "1", "5", "", ""),
        ("", "培训完成率", "%", "0", "90", "", ""),
        ("", "AI素养评分", "分", "20", "70", "", ""),
        ("业务指标\n(Lagging)", "人均产能提升率", "%", "0", "30", "", ""),
        ("", "客户报告生成周期缩短", "%", "0", "40", "", ""),
        ("", "方案策划时间缩短率", "%", "0", "25", "", ""),
        ("", "客户满意度变化", "分", "0", "+5", "", ""),
        ("", "团队加班时长减少率", "%", "0", "20", "", ""),
        ("财务指标", "月度ROI", "%", "0", "150", "", ""),
        ("", "年度节省人工成本", "万元", "0", "50", "", ""),
        ("", "投资回收周期", "月", "-", "6", "", ""),
    ]

    row = 4
    for idx, data in enumerate(kpi_data):
        is_alt = idx % 2 == 1
        for col, val in enumerate(data, 1):
            ws.cell(row=row, column=col, value=val)
        # 达成率公式
        ws.cell(row=row, column=7).value = f'=IF(AND(F{row}<>"",E{row}<>""),F{row}/E{row}*100,"")'
        style_data_row(ws, row, 1, 7, is_alt)
        ws.cell(row=row, column=1).alignment = align_center
        ws.cell(row=row, column=2).alignment = align_left
        ws.row_dimensions[row].height = 30
        row += 1

    set_col_widths(ws, [12, 20, 10, 10, 10, 10, 10])
    return ws


# ============================================================
# Sheet 5: 场景优先级评分矩阵
# ============================================================
def create_scenario_matrix(wb):
    ws = wb.create_sheet("5-场景优先级矩阵")
    
    # 标题
    ws.merge_cells('A1:G1')
    ws['A1'] = "AI应用场景优先级评分矩阵"
    ws['A1'].font = font_title
    ws['A1'].fill = fill_header
    ws['A1'].alignment = align_center
    ws.row_dimensions[1].height = 40

    # 评分说明
    ws.merge_cells('A2:G2')
    ws['A2'] = "评分标准：价值维度(1-10分) × 可行性维度(1-10分) = 优先级得分 | 得分>50为优先推进场景"
    ws['A2'].font = font_small
    ws['A2'].alignment = align_center

    # 表头
    headers = ["场景编号", "AI应用场景", "业务价值(1-10)", "实现难度(1-10)", "可行性得分", "优先级得分", "推进建议"]
    row = 4
    for col, h in enumerate(headers, 1):
        ws.cell(row=row, column=col, value=h)
    style_header_row(ws, row, 1, 7)
    ws.row_dimensions[row].height = 30

    scenarios = [
        ("S1", "客户报告自动生成", "9", "3", "", "", "优先推进 — 高价值低门槛"),
        ("S2", "竞品分析加速", "8", "4", "", "", "优先推进 — 立竿见影"),
        ("S3", "会议纪要与行动项提取", "7", "2", "", "", "优先推进 — 易于上手"),
        ("S4", "社交媒体文案批量创作", "8", "5", "", "", "优先推进 — 创作效率翻倍"),
        ("S5", "方案策划辅助", "9", "6", "", "", "优先推进 — 核心业务赋能"),
        ("S6", "客户需求预测模型", "9", "8", "", "", "规划推进 — 需数据积累"),
        ("S7", "跨平台数据整合分析", "8", "7", "", "", "规划推进 — 技术复杂"),
        ("S8", "个性化营销方案自动生成", "7", "8", "", "", "规划推进 — 需行业知识库"),
        ("S9", "邮件模板生成", "4", "2", "", "", "按需推进 — 价值较低"),
        ("S10", "日程安排优化", "3", "3", "", "", "按需推进 — 非核心场景"),
    ]

    row = 5
    for idx, data in enumerate(scenarios):
        is_alt = idx % 2 == 1
        for col, val in enumerate(data, 1):
            ws.cell(row=row, column=col, value=val)
        # 可行性得分 = 10 - 实现难度
        ws.cell(row=row, column=5).value = f'=IF(D{row}<>"",10-D{row},"")'
        # 优先级得分 = 业务价值 × 可行性得分
        ws.cell(row=row, column=6).value = f'=IF(AND(C{row}<>"",E{row}<>""),C{row}*E{row},"")'
        
        style_data_row(ws, row, 1, 7, is_alt)
        ws.cell(row=row, column=2).alignment = align_left
        ws.cell(row=row, column=7).alignment = align_left
        ws.row_dimensions[row].height = 28
        row += 1

    # 矩阵图说明
    row += 2
    ws.cell(row=row, column=1, value="优先级矩阵分区：")
    ws.cell(row=row, column=1).font = font_body_bold
    row += 1
    matrix_legend = [
        ("🟢 优先推进", "得分 > 50", "高价值 + 高可行性，立即启动"),
        ("🟡 规划推进", "得分 30-50", "高价值 + 低可行性，制定计划逐步推进"),
        ("🔵 按需推进", "得分 < 30", "低价值，根据团队需求决定是否推进"),
    ]
    for label, score, desc in matrix_legend:
        ws.cell(row=row, column=1, value=label).font = font_body_bold
        ws.cell(row=row, column=2, value=score).font = font_body
        ws.cell(row=row, column=3, value=desc).font = font_small
        ws.merge_cells(f'C{row}:G{row}')
        row += 1

    set_col_widths(ws, [10, 22, 12, 12, 10, 10, 18])
    return ws


# ============================================================
# 主执行函数
# ============================================================
def main():
    wb = Workbook()
    # 删除默认sheet
    wb.remove(wb.active)

    # 创建各工作表
    create_maturity_assessment(wb)
    create_training_plan(wb)
    create_roi_dashboard(wb)
    create_kpi_monitor(wb)
    create_scenario_matrix(wb)

    # 保存文件
    output_path = "/Users/apple/Downloads/ai-account-empowerment-skill/AI赋能Account团队-交付物模板.xlsx"
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    wb.save(output_path)
    print(f"✅ Excel交付物已生成：{output_path}")
    print("📋 包含5个工作表：")
    print("   1. AI能力成熟度评估表")
    print("   2. 培训计划与进度追踪表")
    print("   3. ROI计算与效果追踪仪表板")
    print("   4. KPI指标监控表")
    print("   5. 场景优先级评分矩阵")


if __name__ == "__main__":
    main()
